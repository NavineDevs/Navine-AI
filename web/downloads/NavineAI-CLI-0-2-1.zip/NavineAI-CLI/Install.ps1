$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Bin = Join-Path $Here "bin"
New-Item -ItemType Directory -Force -Path $Bin | Out-Null
Copy-Item -Force (Join-Path $Here "navine.cmd") (Join-Path $Bin "navine.cmd")
$UserPath = [Environment]::GetEnvironmentVariable("Path", "User")
if (-not $UserPath) { $UserPath = "" }
$parts = $UserPath -split ";" | Where-Object { $_ -and $_.Trim() -ne "" }
if ($parts -notcontains $Bin) {
  $parts += $Bin
  [Environment]::SetEnvironmentVariable("Path", ($parts -join ";"), "User")
  $env:Path = "$Bin;$env:Path"
}
Write-Host "Installed navine CLI."
Write-Host "Open a NEW terminal and type: navine"
Write-Host "Optional: set NAVINE_ROOT to your Navine AI project folder."
