@echo off
echo Navine AI desktop app is not built yet.
echo Run: cd app ^&^& npm run build
pause
