Navine AI Desktop App (Rust / Tauri)
Version 0.2.1

This package contains the native Windows desktop app built with Rust (Tauri).
It starts the local Navine server and opens the UI in a desktop window.

1. Extract the zip
2. Double-click NavineAI.exe
3. Keep the Navine AI project folder nearby (same PC) so models/venv resolve

You can also set NAVINE_ROOT to your project path before launching.
